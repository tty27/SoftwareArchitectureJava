package healthcare.view;

public class Main {
    public static void main(String[] args) {
        new MainFrame();
    }
}
